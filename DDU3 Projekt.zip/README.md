# Projekt-DDU-
https://github.com/tilde-ad/Projekt-DDU3

Grupp-projekt för kursen DDU3 - Tilde, Maja, Josefin & Sara.

Vi har skapat ett memory-spel med hundtema. Det finns 20 kort, alltså 10 par, där varje par är en egen hundras. För varje par spelaren hittar visas en ruta med en beskrivning av rasen i vänster sida av websidan, med möjligheten att spara ner (eller gilla) hundraser till sitt inlogg, på höger sida.

För var tredje par som hittas visas en slumpmässig fakta om hundar. 

Vi har använt oss av två olika apier, där vi hämtar hundraser och bilder från den ena, och beskrivningar och hundfakta från den andra. 

Om ni vill testa spelet så har vi gjort vars en inloggning till er: 
Användanamn: Sebbe
Lösenord: hej

Användarnamn: Erik
Lösenord: hej